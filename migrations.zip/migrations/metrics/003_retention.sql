-- Enable TimescaleDB background jobs (safety check – does nothing if already enabled)
CREATE EXTENSION IF NOT EXISTS timescaledb;

------------------------------------------------
-- COMPRESSION SETTINGS (enables compression)
------------------------------------------------

-- Enable compression & segment by server_id for better dedup + scanning performance
ALTER TABLE metric_points SET (
  timescaledb.compress,
  compress_segmentby = 'server_id'
);

ALTER TABLE server_metrics SET (
  timescaledb.compress,
  compress_segmentby = 'server_id'
);

------------------------------------------------
-- RETENTION POLICIES (auto-delete old chunks)
------------------------------------------------

-- Delete raw metric_points older than 30 days
SELECT add_retention_policy('metric_points', INTERVAL '30 days')
ON CONFLICT DO NOTHING;

-- Delete server_metrics older than 60 days
SELECT add_retention_policy('server_metrics', INTERVAL '60 days')
ON CONFLICT DO NOTHING;

------------------------------------------------
-- COMPRESSION POLICIES (auto-compress older chunks)
------------------------------------------------

-- Compress metric_points after 7 days
SELECT add_compression_policy('metric_points', INTERVAL '7 days')
ON CONFLICT DO NOTHING;

-- Compress server_metrics after 14 days
SELECT add_compression_policy('server_metrics', INTERVAL '14 days')
ON CONFLICT DO NOTHING;

------------------------------------------------
-- OPTIONAL: WAL protection (avoid WAL bloat)
-- Uncomment if WAL grows uncontrollably
------------------------------------------------
-- ALTER SYSTEM SET wal_keep_size = '512MB';
-- SELECT pg_reload_conf();
